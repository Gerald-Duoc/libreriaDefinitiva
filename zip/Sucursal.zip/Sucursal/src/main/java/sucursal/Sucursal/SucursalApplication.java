package sucursal.Sucursal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SucursalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SucursalApplication.class, args);
	}

}
